import type { FocusEvent } from 'react';
import type { SelectOption } from '../types';

type SelectInputProps = {
  id: string;
  name: string;
  value: string;
  label: string;
  options: SelectOption[];
  placeholder?: string;
  invalid?: boolean;
  describedBy?: string;
  onChange: (value: string) => void;
  onBlur: (event: FocusEvent<HTMLSelectElement>) => void;
};

export function SelectInput({ id, name, value, label, options, placeholder, invalid = false, describedBy, onChange, onBlur }: SelectInputProps) {
  return (
    <select
      className={`ds-control ds-select${value ? ' has-value' : ''}`}
      id={id}
      name={name}
      value={value}
      aria-label={label}
      aria-invalid={invalid}
      aria-describedby={describedBy}
      onChange={(event) => onChange(event.target.value)}
      onBlur={onBlur}
    >
      <option value="" disabled>{placeholder ?? 'Choose an option'}</option>
      {options.map((option) => <option key={option.value} value={option.value}>{option.label}</option>)}
    </select>
  );
}
