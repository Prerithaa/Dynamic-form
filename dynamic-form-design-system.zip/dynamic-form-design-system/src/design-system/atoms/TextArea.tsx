import type { FocusEvent } from 'react';

type TextAreaProps = {
  id: string;
  name: string;
  value: string;
  label: string;
  placeholder?: string;
  maxLength?: number;
  invalid?: boolean;
  describedBy?: string;
  onChange: (value: string) => void;
  onBlur: (event: FocusEvent<HTMLTextAreaElement>) => void;
};

export function TextArea({ id, name, value, label, placeholder, maxLength, invalid = false, describedBy, onChange, onBlur }: TextAreaProps) {
  return (
    <textarea
      className="ds-control ds-textarea"
      id={id}
      name={name}
      value={value}
      aria-label={label}
      aria-invalid={invalid}
      aria-describedby={describedBy}
      placeholder={placeholder}
      maxLength={maxLength}
      rows={4}
      onChange={(event) => onChange(event.target.value)}
      onBlur={onBlur}
    />
  );
}
