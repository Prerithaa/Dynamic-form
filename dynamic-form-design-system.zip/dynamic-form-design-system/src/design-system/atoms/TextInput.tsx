import type { ChangeEvent, FocusEvent } from 'react';

type TextInputProps = {
  id: string;
  name: string;
  type?: 'text' | 'email' | 'tel';
  value: string;
  label: string;
  placeholder?: string;
  invalid?: boolean;
  describedBy?: string;
  onChange: (value: string) => void;
  onBlur: (event: FocusEvent<HTMLInputElement>) => void;
};

export function TextInput({ id, name, type = 'text', value, label, placeholder, invalid = false, describedBy, onChange, onBlur }: TextInputProps) {
  return (
    <input
      className="ds-control"
      id={id}
      name={name}
      type={type}
      value={value}
      aria-label={label}
      aria-invalid={invalid}
      aria-describedby={describedBy}
      placeholder={placeholder}
      onChange={(event: ChangeEvent<HTMLInputElement>) => onChange(event.target.value)}
      onBlur={onBlur}
    />
  );
}
