import type { FocusEvent } from 'react';

type CheckboxInputProps = {
  id: string;
  name: string;
  checked: boolean;
  label: string;
  invalid?: boolean;
  describedBy?: string;
  onChange: (checked: boolean) => void;
  onBlur: (event: FocusEvent<HTMLInputElement>) => void;
};

export function CheckboxInput({ id, name, checked, label, invalid = false, describedBy, onChange, onBlur }: CheckboxInputProps) {
  return (
    <input
      className="ds-checkbox"
      id={id}
      name={name}
      type="checkbox"
      checked={checked}
      aria-label={label}
      aria-invalid={invalid}
      aria-describedby={describedBy}
      onChange={(event) => onChange(event.target.checked)}
      onBlur={onBlur}
    />
  );
}
