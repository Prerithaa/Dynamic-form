import type { ReactNode } from 'react';

type FieldProps = {
  id: string;
  label: string;
  required?: boolean;
  hint?: string;
  error?: string;
  fullWidth?: boolean;
  children: ReactNode;
};

export function Field({ id, label, required = false, hint, error, fullWidth = false, children }: FieldProps) {
  const hintId = hint ? `${id}-hint` : undefined;
  const errorId = error ? `${id}-error` : undefined;
  const describedBy = [hintId, errorId].filter(Boolean).join(' ') || undefined;
  return (
    <div className={`ds-field${fullWidth ? ' ds-field--full' : ''}${error ? ' ds-field--invalid' : ''}`}>
      <label className="ds-label" htmlFor={id}>
        {label}{required && <span className="ds-required" aria-hidden="true"> *</span>}
      </label>
      <div className="ds-field__control" data-described-by={describedBy}>
        {children}
      </div>
      {hint && !error && <p className="ds-hint" id={hintId}>{hint}</p>}
      {error && <p className="ds-error" id={errorId} role="alert">{error}</p>}
    </div>
  );
}
