export type FieldName =
  | 'fullName'
  | 'email'
  | 'leadType'
  | 'companyName'
  | 'phone'
  | 'notes'
  | 'consent';

export type FieldType = 'text' | 'email' | 'select' | 'textarea' | 'checkbox';

export type ValidationRules = {
  required?: boolean;
  email?: boolean;
  digits?: number;
  maxLength?: number;
};

export type SelectOption = { label: string; value: string };

export type FieldConfig = {
  name: FieldName;
  type: FieldType;
  label: string;
  placeholder?: string;
  hint?: string;
  options?: SelectOption[];
  validations: ValidationRules;
  condition?: { field: FieldName; equals: string | boolean };
  layout?: 'default' | 'full';
};

export type FormValues = Record<FieldName, string | boolean>;
export type FormErrors = Partial<Record<FieldName, string>>;
