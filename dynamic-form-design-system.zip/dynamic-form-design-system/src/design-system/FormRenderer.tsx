import type { FocusEvent } from 'react';
import { CheckboxInput } from './atoms/CheckboxInput';
import { SelectInput } from './atoms/SelectInput';
import { TextArea } from './atoms/TextArea';
import { TextInput } from './atoms/TextInput';
import { Field } from './molecules/Field';
import type { FieldConfig, FieldName, FormErrors, FormValues } from './types';

type FormRendererProps = {
  config: FieldConfig[];
  values: FormValues;
  errors: FormErrors;
  touched: Partial<Record<FieldName, boolean>>;
  submitted: boolean;
  onValueChange: (name: FieldName, value: string | boolean) => void;
  onBlur: (name: FieldName) => void;
};

function isVisible(field: FieldConfig, values: FormValues) {
  if (!field.condition) return true;
  return values[field.condition.field] === field.condition.equals;
}

export function FormRenderer({ config, values, errors, touched, submitted, onValueChange, onBlur }: FormRendererProps) {
  return (
    <div className="lead-form-grid">
      {config.filter((field) => isVisible(field, values)).map((field) => {
        const id = `lead-${field.name}`;
        const error = (touched[field.name] || submitted) ? errors[field.name] : undefined;
        const invalid = Boolean(error);
        const value = values[field.name];
        const describedBy = error ? `${id}-error` : field.hint ? `${id}-hint` : undefined;
        const blur = (_event: FocusEvent<HTMLElement>) => onBlur(field.name);

        let control;
        switch (field.type) {
          case 'text':
          case 'email':
            control = (
              <TextInput
                id={id}
                name={field.name}
                type={field.type}
                value={typeof value === 'string' ? value : ''}
                label={field.label}
                placeholder={field.placeholder}
                invalid={invalid}
                describedBy={describedBy}
                onChange={(next) => onValueChange(field.name, next)}
                onBlur={blur}
              />
            );
            break;
          case 'select':
            control = (
              <SelectInput
                id={id}
                name={field.name}
                value={typeof value === 'string' ? value : ''}
                label={field.label}
                options={field.options ?? []}
                placeholder={field.placeholder}
                invalid={invalid}
                describedBy={describedBy}
                onChange={(next) => onValueChange(field.name, next)}
                onBlur={blur}
              />
            );
            break;
          case 'textarea':
            control = (
              <TextArea
                id={id}
                name={field.name}
                value={typeof value === 'string' ? value : ''}
                label={field.label}
                placeholder={field.placeholder}
                maxLength={field.validations.maxLength}
                invalid={invalid}
                describedBy={describedBy}
                onChange={(next) => onValueChange(field.name, next)}
                onBlur={blur}
              />
            );
            break;
          case 'checkbox':
            control = (
              <CheckboxInput
                id={id}
                name={field.name}
                checked={value === true}
                label={field.label}
                invalid={invalid}
                describedBy={describedBy}
                onChange={(next) => onValueChange(field.name, next)}
                onBlur={blur}
              />
            );
            break;
        }

        return (
          <div className={field.layout === 'full' || field.type === 'checkbox' ? 'lead-form-grid__full' : ''} key={field.name}>
            {field.type === 'checkbox' ? (
              <div className={`consent-row${invalid ? ' consent-row--invalid' : ''}`}>
                {control}
                <div className="consent-row__copy">
                  <label htmlFor={id}>{field.label}<span className="ds-required" aria-hidden="true"> *</span></label>
                  <p>I agree to be contacted about my enquiry and understand my information will be handled according to the privacy policy.</p>
                  {field.hint && !error && <p className="ds-hint" id={`${id}-hint`}>{field.hint}</p>}
                  {error && <p className="ds-error" id={`${id}-error`} role="alert">{error}</p>}
                </div>
              </div>
            ) : (
              <Field id={id} label={field.label} required={field.validations.required} hint={field.hint} error={error} fullWidth={field.layout === 'full'}>
                {control}
                {field.name === 'notes' && <div className="character-count">{String(value).length}/200 characters</div>}
              </Field>
            )}
          </div>
        );
      })}
    </div>
  );
}
