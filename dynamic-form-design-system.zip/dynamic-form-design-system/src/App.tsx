import { LeadFormPage } from './features/lead/LeadFormPage';

export default function App() {
  return <LeadFormPage />;
}
