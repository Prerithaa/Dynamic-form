import type { FieldConfig, FieldName, FormValues } from '../../design-system/types';

export const leadFormConfig: FieldConfig[] = [
  {
    name: 'fullName', type: 'text', label: 'Full name', placeholder: 'e.g. Alex Morgan',
    validations: { required: true },
  },
  {
    name: 'email', type: 'email', label: 'Work email', placeholder: 'you@company.com',
    validations: { required: true, email: true },
  },
  {
    name: 'leadType', type: 'select', label: 'Lead type', placeholder: 'Choose lead type',
    options: [
      { label: 'Individual', value: 'Individual' },
      { label: 'Company', value: 'Company' },
    ],
    validations: { required: true },
  },
  {
    name: 'companyName', type: 'text', label: 'Company name', placeholder: 'Your company name',
    validations: { required: true },
    condition: { field: 'leadType', equals: 'Company' },
  },
  {
    name: 'phone', type: 'text', label: 'Phone number', placeholder: '10-digit mobile number',
    hint: 'Enter 10 digits, without the country code.',
    validations: { required: true, digits: 10 },
  },
  {
    name: 'notes', type: 'textarea', label: 'Anything else we should know?', placeholder: 'Tell us a little about what you need…',
    hint: 'Optional · Up to 200 characters', validations: { maxLength: 200 }, layout: 'full',
  },
  {
    name: 'consent', type: 'checkbox', label: 'I agree to be contacted',
    validations: { required: true }, layout: 'full',
  },
];

export const initialLeadValues: FormValues = {
  fullName: '', email: '', leadType: '', companyName: '', phone: '', notes: '', consent: false,
};

export const leadFieldLabels: Record<FieldName, string> = {
  fullName: 'Full name', email: 'Work email', leadType: 'Lead type', companyName: 'Company name',
  phone: 'Phone number', notes: 'Notes', consent: 'Consent',
};
