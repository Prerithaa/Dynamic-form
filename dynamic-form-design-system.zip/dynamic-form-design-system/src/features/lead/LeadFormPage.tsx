import { useMemo, useState, type FormEvent } from 'react';
import { Button } from '../../design-system/atoms/Button';
import { FormRenderer } from '../../design-system/FormRenderer';
import type { FieldName, FormErrors, FormValues } from '../../design-system/types';
import { initialLeadValues, leadFieldLabels, leadFormConfig } from './leadConfig';
import { validateForm } from './validation';
import './lead-form.css';

type SubmittedLead = FormValues;

export function LeadFormPage() {
  const [values, setValues] = useState<FormValues>(initialLeadValues);
  const [errors, setErrors] = useState<FormErrors>({});
  const [touched, setTouched] = useState<Partial<Record<FieldName, boolean>>>({});
  const [submitted, setSubmitted] = useState(false);
  const [result, setResult] = useState<SubmittedLead | null>(null);

  const currentErrors = useMemo(() => validateForm(leadFormConfig, values), [values]);
  const errorCount = Object.keys(currentErrors).length;

  function handleValueChange(name: FieldName, value: string | boolean) {
    const nextValues: FormValues = { ...values, [name]: value };
    // Clear conditional data when the field no longer applies.
    if (name === 'leadType' && value !== 'Company') nextValues.companyName = '';
    setValues(nextValues);
    setResult(null);
    if (submitted) {
      // Once submit has been attempted, keep every visible error in sync as the user fixes fields.
      setErrors(validateForm(leadFormConfig, nextValues));
    } else {
      setErrors((previous) => {
        const next = { ...previous };
        delete next[name];
        if (name === 'leadType' && value !== 'Company') delete next.companyName;
        return next;
      });
    }
  }

  function handleBlur(name: FieldName) {
    setTouched((previous) => ({ ...previous, [name]: true }));
    setErrors(validateForm(leadFormConfig, values));
  }

  function handleSubmit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    const nextErrors = validateForm(leadFormConfig, values);
    setErrors(nextErrors);
    setSubmitted(true);
    setTouched((previous) => {
      const allVisible: Partial<Record<FieldName, boolean>> = { ...previous };
      leadFormConfig.forEach((field) => {
        if (!field.condition || values[field.condition.field] === field.condition.equals) allVisible[field.name] = true;
      });
      return allVisible;
    });
    if (Object.keys(nextErrors).length > 0) {
      setResult(null);
      const firstError = leadFormConfig.find((field) => nextErrors[field.name]);
      if (firstError) document.getElementById(`lead-${firstError.name}`)?.focus();
      return;
    }
    setResult({ ...values });
  }

  function startNewLead() {
    setValues(initialLeadValues);
    setErrors({});
    setTouched({});
    setSubmitted(false);
    setResult(null);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }

  return (
    <main className="page-shell">
      <header className="topbar">
        <a className="brand" href="#top" aria-label="Northstar home">
          <span className="brand__mark" aria-hidden="true"><span /></span>
          <span>northstar<span className="brand__dot">.</span></span>
        </a>
        <div className="topbar__right"><span className="secure-dot" /> Secure lead capture</div>
      </header>

      <section className="content-wrap" id="top">
        <div className="intro">
          <div className="eyebrow"><span className="eyebrow__line" /> LET'S GET TO KNOW YOU</div>
          <h1>Let’s start a<br className="desktop-break" /> <span>conversation.</span></h1>
          <p className="intro__copy">Share a few details and our team will get back to you with the right next steps. It only takes a minute.</p>
          <div className="trust-note"><span className="trust-note__icon" aria-hidden="true">✓</span> Your details stay private and secure</div>
        </div>

        <section className="form-card" aria-labelledby="form-title">
          {result ? (
            <div className="success-state" role="status" aria-live="polite">
              <div className="success-state__icon" aria-hidden="true">✓</div>
              <p className="success-state__eyebrow">ALL SET</p>
              <h2 id="form-title">Thanks, {String(result.fullName).split(' ')[0]}!</h2>
              <p>Your details have been captured. Here’s a summary of what you submitted.</p>
              <dl className="result-list">
                {leadFormConfig.filter((field) => field.name !== 'consent' && (!field.condition || result[field.condition.field] === field.condition.equals) && String(result[field.name]).trim()).map((field) => (
                  <div className="result-list__row" key={field.name}>
                    <dt>{leadFieldLabels[field.name]}</dt><dd>{String(result[field.name])}</dd>
                  </div>
                ))}
                <div className="result-list__row"><dt>Consent</dt><dd>{result.consent ? 'Granted' : 'Not granted'}</dd></div>
              </dl>
              <Button onClick={startNewLead}>Create another lead <span aria-hidden="true">→</span></Button>
            </div>
          ) : (
            <>
              <div className="form-card__heading">
                <div>
                  <p className="form-step">YOUR DETAILS <span>01 / 01</span></p>
                  <h2 id="form-title">Tell us about yourself</h2>
                  <p className="form-card__subcopy">Fields marked with <span className="ds-required">*</span> are required.</p>
                </div>
                <div className="form-card__badge" aria-hidden="true"><span>✳</span></div>
              </div>

              {submitted && errorCount > 0 && (
                <div className="error-summary" role="alert" aria-live="polite">
                  <span className="error-summary__icon" aria-hidden="true">!</span>
                  <div><strong>Almost there</strong><p>Please fix {errorCount} {errorCount === 1 ? 'field' : 'fields'} below to continue.</p></div>
                </div>
              )}

              <form noValidate onSubmit={handleSubmit}>
                <FormRenderer
                  config={leadFormConfig}
                  values={values}
                  errors={errors}
                  touched={touched}
                  submitted={submitted}
                  onValueChange={handleValueChange}
                  onBlur={handleBlur}
                />
                <div className="form-actions">
                  <p><span className="action-lock" aria-hidden="true">▣</span> Your information is encrypted and secure.</p>
                  <Button type="submit" className="submit-button">Submit details <span aria-hidden="true">→</span></Button>
                </div>
              </form>
            </>
          )}
        </section>
      </section>

      <footer className="page-footer">
        <span>© 2026 Northstar</span><span>Thoughtful conversations start here.</span>
      </footer>
    </main>
  );
}
