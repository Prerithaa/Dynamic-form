import type { FieldConfig, FieldName, FormErrors, FormValues } from '../../design-system/types';

function isVisible(field: FieldConfig, values: FormValues): boolean {
  if (!field.condition) return true;
  return values[field.condition.field] === field.condition.equals;
}

/** Pure validation: same config + values always produce the same errors. */
export function validateForm(config: FieldConfig[], values: FormValues): FormErrors {
  const errors: FormErrors = {};

  for (const field of config) {
    if (!isVisible(field, values)) continue;

    const value = values[field.name];
    const stringValue = typeof value === 'string' ? value.trim() : '';
    const rules = field.validations;

    if (rules.required) {
      const empty = field.type === 'checkbox' ? value !== true : stringValue.length === 0;
      if (empty) {
        errors[field.name] = field.type === 'checkbox'
          ? 'Please give your consent to continue.'
          : `${field.label} is required.`;
        continue;
      }
    }

    if (rules.email && stringValue && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(stringValue)) {
      errors[field.name] = 'Enter a valid email address.';
      continue;
    }

    if (rules.digits && stringValue && !new RegExp(`^\\d{${rules.digits}}$`).test(stringValue)) {
      errors[field.name] = `Enter a ${rules.digits}-digit phone number.`;
      continue;
    }

    if (rules.maxLength && typeof value === 'string' && value.length > rules.maxLength) {
      errors[field.name] = `${field.label} must be ${rules.maxLength} characters or fewer.`;
    }
  }

  return errors;
}

export function validateField(config: FieldConfig[], values: FormValues, name: FieldName): string | undefined {
  return validateForm(config, values)[name];
}
